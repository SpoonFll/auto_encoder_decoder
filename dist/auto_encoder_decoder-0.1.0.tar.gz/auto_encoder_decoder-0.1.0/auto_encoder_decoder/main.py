#!/usr/bin/env python3

import torch
import numpy as np

def main():
    print("hello world")

if __name__ == '__main__':
    main()
